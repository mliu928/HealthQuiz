package com.example.marcusprime7.healthquiz;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void getResults (View view) {
        /*
        creates an array of answers
         */
    }
    boolean answerArray[];
    answerArray = new boolean[10];
    RadioButton answer = (RadioButton) findViewById(R.id.answerOne);
    answerArray[0] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerTwo);
    answerArray[1] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerThree);
    answerArray[2] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerFour);
    answerArray[3] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerFive);
    answerArray[4] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerSix);
    answerArray[5] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerSeven);
    answerArray[6] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerEight);
    answerArray[7] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerNine);
    answerArray[8] = answer.isChecked();
    answer = (RadioButton) findViewById(R.id.answerTen);
    answerArray[9] = answer.isChecked();

    /*score calculation */

    int score = calculateScore(answerArray);

}

    private int calculateScore (boolean scoreArray[]) {
        int methodScore = 0;
        for(int i=0; i<10; i++) {
            if (scoreArray[i]) {
                methodScore = methodScore + 1;
            }
        }
        return methodScore
    }

    private void displayScore (int finalScore {

        Toast ScoreMessage = Toast.makeText(this,"You get ()")
    }

    public void correctAnswers (View view) {
    /*
    this part scrolls the screen back to the top of the view
     */
        ScrollView scrollToTop = (scrollView) findViewById(R.id.mainScrollView);
        scrollToTop.fullScroll(ScrollView.FOCUS_UP);
    /*
    this part sets the radio buttons for each RadioGroup to correct answer
     */

        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupOne);
        choiceGroup.check(R.id.answerOne);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupTwo);
        choiceGroup.check(R.id.answerTwo);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupThree);
        choiceGroup.check(R.id.answerThree);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupFour);
        choiceGroup.check(R.id.answerFour);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupFive);
        choiceGroup.check(R.id.answerFive);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupSix);
        choiceGroup.check(R.id.answerSix);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupSeven);
        choiceGroup.check(R.id.answerSeven);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupEight);
        choiceGroup.check(R.id.answerEight);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupNine);
        choiceGroup.check(R.id.answerNine);
        RadioGroup choiceGroup = (RadioGroup) findViewById(R.id.groupTen);
    }choiceGroup.check(R.id.answerTen);


    public void resetTest (View view){
    /*
    this part scrolls the screen back to the top fo the view
     */

        ScrollView scrollToTop=(ScrollView)findViewById(R.id.mainScrollView);
        scrollToTop.fullScroll(ScrollView.FOCUS_UP);
    /*
    this part resets the RadioGroups
     */
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupOne);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupTwo);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupThree);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupFour);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupFive);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupSix);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupSeven);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupEight);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupNine);
        choiceGroup.clearCheck();
        RadioGroup choiceGroup=(RadioGroup)findViewById(R.id.groupTen);
        choiceGroup.clearCheck();


        /*informative toast*/
        Toast resetMessage=Toast.makeText(this,"May your next test be better than the last",Toast.LENGTH_LONG);
        resetMessage.show();
        }
